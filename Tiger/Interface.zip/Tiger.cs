﻿namespace $rootnamespace$;

public interface $safeitemname$
{
}
