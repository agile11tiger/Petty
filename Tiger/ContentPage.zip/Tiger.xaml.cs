namespace $rootnamespace$;

public partial class $safeitemname$Page : ContentView
{
	public $safeitemname$($safeitemname$ViewModel viewModel)
	{
		BindingContext = viewModel;
		InitializeComponent();
	}
}