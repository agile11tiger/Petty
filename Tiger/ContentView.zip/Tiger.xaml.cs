namespace $rootnamespace$;

public partial class $safeitemname$ : ContentView
{
	public $safeitemname$($safeitemname$ViewModel viewModel)
	{
		BindingContext = viewModel;
		InitializeComponent();
	}
}