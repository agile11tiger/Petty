﻿namespace $rootnamespace$;

public class $safeitemname$ : Service
{
}
