﻿using Petty.ViewModels.Base;
namespace $rootnamespace$;

public partial class $safeitemname$ : ViewModelBase
{
}
